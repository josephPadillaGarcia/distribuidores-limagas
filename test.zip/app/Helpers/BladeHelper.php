<?php

namespace App\Helpers;

class BladeHelper
{
    /*public static function getCustomRoute($name, $locale, $params = null)
    {
        if($locale) {
            // return Route($name, [...$params, 'locale' => $locale]);
            if(!$params) {
                return Route($name, ['locale' => $locale]);
            }
            return Route($name, array_merge($params, ['locale' => $locale]));
        } else {
            return Route($name, $params);
        }
    }*/
}