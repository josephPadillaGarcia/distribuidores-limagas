<?php $__env->startSection('content'); ?>
    <sucursales
    message-order="<?php echo app('translator')->get('custom.message.order'); ?>"
    route="<?php echo e(route('cms.distribuidores.index')); ?>" 
    route-order="<?php echo e(route('cms.distribuidores.order')); ?>"
    images-url="<?php echo e(config('services.images_url')); ?>"
    route-get-all="<?php echo e(route('cms.distribuidores.get-all')); ?>"
    route-departments-get="<?php echo e(route('cms.json.get-departments')); ?>"
    route-provinces-get="<?php echo e(route('cms.json.get-provinces')); ?>"
    route-districts-get="<?php echo e(route('cms.json.get-districts')); ?>"

    route-products-get-all = "<?php echo e(route('cms.distribuidores.product-get-all')); ?>"

    route-items-get-all = "<?php echo e(route('cms.distribuidores.get-items-all')); ?>"

    route-payment-method-get-all = "<?php echo e(route('cms.distribuidores.payment-method-get-all')); ?>"
    ></sucursales>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-frelos\distribuidores-limagas\resources\views/admin/pages/sucursales.blade.php ENDPATH**/ ?>