<?php $__env->startSection('content'); ?>
   <dashboard images-url="<?php echo e(config('services.images_url')); ?>"></dashboard>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-frelos\distribuidores-limagas\resources\views/admin/pages/dashboard.blade.php ENDPATH**/ ?>