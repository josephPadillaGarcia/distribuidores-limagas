<?php $__env->startSection('content'); ?>
<?php
    $locale = Config::get('app.locale');
    //$content = $data["content"];
    $offices = $data["offices"];
    $departments = $data["departments"];
    $departamento = $data["departamento"];
    $provincia = $data["provincia"];
    $distrito = $data["distrito"];
    $storageUrl = config('services.storage_url');

    $numoffices = count($offices);
?>
<main>


<header class="img-bg" style="background-image: url( <?php echo e($storageUrl.'/img/fondo1.jpg'); ?> );">
    <div class="container header-filter">
        <div class="logo">
            <a href="/"><img src="<?php echo e($storageUrl.'/img/logo1.png'); ?>" alt=""></a>
        </div>
        <div class="nav_busqueda color_white">
            <div>Departamento: <b><?php echo e($departamento); ?></b></div>
            <div class="line"></div>
            <div>Provincia: <b><?php echo e($provincia); ?></b></div>
            <div class="line"></div>
            <div>Distrito: <b><?php echo e($distrito); ?></b></div>
        </div>
        <div class="align-center">
            <a href="<?php echo e(route("index")); ?>" class="btn btn1 btn-icon"> Otra ubicación</a>
        </div>
    </div>
</header>


<section class="section">
    <div class="container">
        <div class="text-center padding"><?php echo e($numoffices); ?> Distribuidores encontrados:</div>

        <div class="grid-col">

            <?php $__currentLoopData = $offices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $office): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="grid-s-12 grid-m-6">
                    <div class="card card-distribuidor">
                        <div class="content">
                            <h3><?php echo e($office->name); ?></h3>
                            <ul>
                                <li><i class="flaticon flaticon-star"> </i><?php echo $office->direction; ?></li>
                                
                                <?php if($office->phone_numbers): ?>
                                    <li>    
                                        <?php $__currentLoopData = $office->phone_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <i class="flaticon flaticon-telefono"> </i>
                                            <a href="tel:<?php echo e($ph['number']); ?>" target="_blank"> <?php echo e($ph['number']); ?></a> <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                <?php endif; ?>

                            </ul>
                        </div>

                        <div class="img">
                            <!--img src="public/img/banner1.jpg" alt=""-->
                            <img class="lazyload" src="<?php echo e($storageUrl . '/img/sliders/' . $office->img_slider_1); ?>" alt="<?php echo e($office->name); ?>" />
                            <a href="<?php echo e(route('distribuidor',$office->id )); ?>" class=""><i class="flaticon flaticon-proximo"></i></a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>

    </div>
    
</section>

<div class="pie"></div>

</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-frelos\distribuidores-limagas\resources\views/web/pages/lista-distribuidores.blade.php ENDPATH**/ ?>