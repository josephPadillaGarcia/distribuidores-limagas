<?php $__env->startSection('content'); ?>

    <content-general-information
    route-update="<?php echo e(route('cms.content.general-information.store')); ?>" 
    route-get="<?php echo e(route('cms.content.general-information.get')); ?>"
    images-url="<?php echo e(config('services.images_url')); ?>"
    >
    
</content-general-information>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-frelos\distribuidores-limagas\resources\views/admin/pages/content/general-information.blade.php ENDPATH**/ ?>