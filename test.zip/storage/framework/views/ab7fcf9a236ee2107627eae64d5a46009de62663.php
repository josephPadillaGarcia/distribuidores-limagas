<?php $__env->startSection('content'); ?>
<?php
    $locale = Config::get('app.locale');
    //$content = $data["content"];
    $offices = $data["offices"];
    $departments = $data["departments"];
    $storageUrl = config('services.storage_url');
    $information = $data["information"];
?>

<main>


    <section id="index" style="background-image: url(<?php echo e($storageUrl.'/img/fondo1.jpg'); ?>);">
        <div class="busqueda_index color_white">
            <div class="logo">
                <img src="<?php echo e($storageUrl.'/img/logo1.png'); ?> " alt="">
            </div>
            <div class="texto">
                <h1>Encuentra el distribuidor más cercano a ti:</h1>
            </div>

            <div class="formulario">
                <ubigeo-filter locale="<?php echo e($locale); ?>"
                    department-parent="<?php echo e($department); ?>"
                    province-parent="<?php echo e($province); ?>"
                    district-parent="<?php echo e($district); ?>"
                    route-search="<?php echo e(LaravelLocalization::getURLFromRouteNameTranslated( Config::get('app.locale') , 'routes.branch-offices')); ?>" :departments="<?php echo e($departments); ?>" route-get-prov="<?php echo e(route('web.provinces')); ?>"
                    route-get-dis="<?php echo e(route('web.districts')); ?>"
                    route-lista-distribuidores="<?php echo e(route('web.listadistribuidores')); ?>"
                    />
            </div>

            <div class="redes">
                <span>Síguenos en:</span>
                <?php if($information->facebook_link): ?>
                    <a href="<?php echo e($information->facebook_link); ?>" class="btn-circle"><i class="flaticon-facebook"></i></a>
                <?php endif; ?>

                <?php if($information->instagram_link): ?>
                    <a href="<?php echo e($information->instagram_link); ?>" class="btn-circle"><i class="flaticon-instagram"></i></a>
                <?php endif; ?>

                <?php if($information->youtube_link): ?>
                    <a href="<?php echo e($information->youtube_link); ?>" class="btn-circle"><i class="flaticon-youtube"></i></a>
                <?php endif; ?>
                
                <?php if($information->linkedin_link): ?>
                    <a href="<?php echo e($information->linkedin_link); ?>" class="btn-circle"><i class="flaticon-linkedin"></i></a>
                <?php endif; ?>
            </div>
        </div>
    
        <div class="img-footer">
            <div class="left"><img src=" <?php echo e($storageUrl.'/img/img-left.png'); ?> " alt=""></div>
            <div class="right"><img src="<?php echo e($storageUrl.'/img/img-right.png'); ?>" alt=""></div>
        </div>
    </section>

    <div class="pie"></div>

</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    function getPr(e){
        let value = document.getElementById("department").value;
        console.log(value);
        fetch('<?php echo e(route("web.provinces", array("department" => ":value") )); ?>')
        .then(response => response.json())
        .then(data => console.log(data));
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/web/pages/branch-office.blade.php ENDPATH**/ ?>