<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>

<nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white py-2" id="sidenav-main">
    <div class="container-fluid">
        <button-menu></button-menu>
        <!-- Brand -->
        <a class="navbar-brand" href="<?php echo e(route('cms.dashboard')); ?>">
            <img src="/storage/img/icon.png" class="align-middle d-block d-md-none logo-mini mx-auto" height="50" width="auto" />
            <img src="/storage/img/logo-limagas-color.png" class="align-middle d-none d-md-block logo mx-auto" height="40" width="auto" />
        </a>
        <!-- User -->
        <ul class="nav align-items-center d-md-none">
            <li class="nav-item dropdown">
                <b-dropdown id="id_dropdown_navbar" class="nav-link border-0 pr-0" :lazy="true" variant="link" v-cloak>
                    <template slot="button-content">
                        <div class="media align-items-center">
                            <span class="avatar avatar-sm rounded-circle bg-default">
                                <?php if(Auth::user()->avatar): ?>
                                <img src="<?php echo e(route('cms.get-file',[ 'folder' => 'img', 'subfolder' => 'users', 'file' => Auth::user()->avatar ])); ?>" alt="User">
                                <?php else: ?>
                                <?php echo e(Auth::user()->avatar_initials); ?>

                                <?php endif; ?>
                            </span>
                        </div>
                    </template>
                    <b-dropdown-item href="<?php echo e(route('cms.profile')); ?>">
                        <span class="ri-passport-line ri-lg current-color mr-2"></span> <span class="v-align-middle">Mi perfil</span>
                    </b-dropdown-item>
                    <b-dropdown-divider></b-dropdown-divider>
                    <b-dropdown-item href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <span class="ri-shut-down-line ri-lg current-color text-danger mr-2"></span> <span class="v-align-middle">Cerrar Sesión</span>
                    </b-dropdown-item>
                </b-dropdown>

            </li>
        </ul>
        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
            <?php echo e(csrf_field()); ?>

        </form>
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
            <!-- Collapse header -->
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('cms.dashboard')); ?>">
                            <img src="/storage/img/logo.png" class="align-middle" height="70px" width="auto" />
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button-close></button-close>
                    </div>
                </div>
            </div>
            <ul class="navbar-nav">
                <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="nav-item">
                    <?php if(isset($module["menu_secondary"])): ?>
                    <a class="nav-link position-relative d-inline-block w-100 py-3 <?php echo e(Request::segment(2) ==  $module["variable"] ? 'active' : ''); ?>" v-b-toggle.<?php echo e($module["variable"]); ?>>
                    <span class="current-color mr-3 ri-lg ri-<?php echo e($module["icon"]); ?>-line"></span>
                        <span class="nav-link__text"><?php echo e($module["name"]); ?></span> 
                        <span class="arrow"><i class="menu-arrow">
                        <span class="current-color ri-arrow-right-line" data-with="16" data-height="16"></span>
                            </i></span>
                    </a>
                    <b-collapse id="<?php echo e($module["variable"]); ?>" v-cloak>
                        <ul class="nav flex-column sub-menu">
                            <?php $__currentLoopData = $module["menu_secondary"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link  <?php echo e(Request::path() ==  $submodule["slug"] ? 'active' : ''); ?>" href="/admin/<?php echo e($submodule["slug"]); ?>"><?php echo e($submodule["name"]); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </b-collapse>

                    <a class="nav-link position-relative text-center d-inline-block w-100 py-3 nav-link--hover <?php echo e(Request::segment(2) ==  $module["variable"] ? 'active' : ''); ?>" :id="'popover-<?php echo e($module["variable"]); ?>'">

                    <span class="current-color mr-3 ri-lg ri-<?php echo e($module["icon"]); ?>-line"></span>
                    </a>
                    <b-popover :target="'popover-<?php echo e($module["variable"]); ?>'" custom-class="ml-0 shadow-none pl-0 pt-1 pb-2" triggers="hover" placement="right" v-cloak>
                        <template v-slot:title>
                            <div class="ml-2 text-primary"><?php echo e($module["name"]); ?></div>
                        </template>
                        <ul class="nav flex-column sub-menu">
                            <?php $__currentLoopData = $module["menu_secondary"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submodule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="nav-item">
                                <a class="nav-link py-1 px-0" href="/admin/<?php echo e($submodule["slug"]); ?>"><?php echo e($submodule["name"]); ?></a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </b-popover>
                    <?php else: ?>
                    <a class="nav-link position-relative d-inline-block w-100 py-3 <?php echo e(Request::segment(2) ==  $module["variable"] ? 'active' : ''); ?>" href="/admin/<?php echo e($module["slug"]); ?>">
                        <span class="current-color mr-3  ri-lg ri-<?php echo e($module["icon"]); ?>-line"></span>
                        <span class="nav-link__text"><?php echo e($module["name"]); ?></span>
                    </a>
                    <a class="nav-link position-relative text-center d-inline-block w-100 py-3 nav-link--hover <?php echo e(Request::segment(2) ==  $module["variable"] ? 'active' : ''); ?>" :id="'popover-<?php echo e($module["slug"]); ?>'">
                        <span class="current-color mr-3  ri-lg ri-<?php echo e($module["icon"]); ?>-line"></span>
                    </a>
                    <b-popover :target="'popover-<?php echo e($module["slug"]); ?>'" custom-class="ml-0 shadow-none pl-0 pr-5" triggers="hover" placement="right" v-cloak>
                        <a class="nav-link pt-1 px-0" href="/admin/<?php echo e($module["slug"]); ?>">
                            <span class="link__text"><?php echo e($module["name"]); ?></span>
                        </a>
                    </b-popover>
                    <?php endif; ?>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    </div>
</nav>


<div class="main-content" id="main-content">
    <nav class="navbar navbar-top navbar-expand navbar-light position-relative bg-white py-2 d-md-flex align-items-center d-none" id="navbar-main">
        <div class="container-fluid">
            <button-icons></button-icons>
            <div class="d-inline-block ml-4">
                <a href="<?php echo e(config('services.web_url')); ?>" target="_blank" class="btn btn-icon btn-inverse-primary mr-2">
                    <span class="btn-inner--icon"></span>
                    <span class="btn-inner--text">
                        Ir a la Web</span> </a>
            </div>
            <ul class="navbar-nav align-items-center d-none d-md-flex ml-auto">
                <li class="nav-item">
                    <b-dropdown id="id_dropdown_navbar" class="border-0 pr-0" :lazy="true" variant="link" v-cloak>
                        <template slot="button-content">
                            <div class="media align-items-center">
                                <span class="avatar avatar-sm rounded-circle bg-default">
                                    <?php if(Auth::user()->avatar): ?>
                                    <img src="<?php echo e(route('cms.get-file',[ 'folder' => 'img', 'subfolder' => 'users', 'file' => Auth::user()->avatar ])); ?>" alt="Usuario" />
                                    <?php else: ?>
                                    <?php echo e(Auth::user()->avatar_initials); ?>

                                    <?php endif; ?>
                                </span>
                                <div class="media-body ml-2">
                                    <span class="mb-0 font-weight-semibold"><?php echo e(Auth::user()->name); ?></span>
                                </div>
                            </div>
                        </template>
                        <b-dropdown-item class="my-1" href="<?php echo e(route('cms.profile')); ?>">
                        <span class="ri-passport-line ri-lg current-color mr-2"></span> <span class="v-align-middle"> <span class="v-align-middle">Mi perfil</span>
                        </b-dropdown-item>
                        <b-dropdown-divider></b-dropdown-divider>
                        <b-dropdown-item class="my-1" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <span class="ri-shut-down-line ri-lg current-color text-danger mr-2"></span><span class="v-align-middle">Cerrar Sesión</span>
                        </b-dropdown-item>
                    </b-dropdown>
                </li>
            </ul>
        </div>
    </nav>
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="pb-2 footer pt-2 mt-5">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12 text-center text-sm-right">
                    <small class=" d-block d-sm-inline-block">Copyright © <?php echo date('Y') ?> <a href="https://playgroup.pe" target="_blank" class="text-primary">PLAY Group</a>. All rights reserved.</small>
                </div>
            </div>
        </div>
    </footer>
</div>
<div id="alert"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    const app = new Vue({
        el: '#alert',
        created() {
            <?php if(Session::has('success')): ?>
            Swal.fire({
                title: "<?php echo e(trans('custom.title.success')); ?>",
                text: "<?php echo e(Session::get('success')); ?>",
                type: "success",
                confirmButtonText: "OK",
                buttonsStyling: false,
                customClass: {
                    confirmButton: "btn btn-inverse-primary"
                }
            });
            <?php endif; ?>
            <?php if(Session::has('error')): ?>
            Swal.fire({
                title: "<?php echo e(trans('custom.title.error')); ?>",
                text: "<?php echo e(Session::get('error')); ?>",
                type: "error",
                confirmButtonText: "OK",
                buttonsStyling: false,
                customClass: {
                    confirmButton: "btn btn-inverse-primary"
                }
            });
            <?php endif; ?>
        }
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/admin/layouts/dashboard.blade.php ENDPATH**/ ?>