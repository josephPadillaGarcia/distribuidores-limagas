<?php $__env->startSection('head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page'); ?>
    <div class="login-container">
        <div class="container-fluid h-100">
            <div class="row h-100">
                <div class="col-lg-6 d-none h-100 login-bg d-lg-flex justify-content-center align-items-center" style="background-image: url(<?php echo e(asset('storage/img/lima-gas-fondo.jpg')); ?>)">
                   
                </div>
                <div class="col-12 col-lg h-100 bg-white">
                    <login 
                    ruta-login="<?php echo e(route('login.post',[],false)); ?>" 
                    ruta-restablecer-contrasena="<?php echo e(route('password.email')); ?>"                     
                    images-url="<?php echo e(config('services.images_url')); ?>"
                    ></login>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app',["class" => "login"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/admin/pages/auth/login.blade.php ENDPATH**/ ?>