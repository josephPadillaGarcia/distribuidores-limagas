<?php $__env->startSection('content'); ?>
<?php
    $storageUrl = config('services.storage_url');
?>

<header class="header-distribuidor img-bg" style="background-image: url(<?php echo e($storageUrl.'/img/fondo1.jpg'); ?>);">
    <div class="container-short grid-single color_white">
        <div class="logo">
            <a href="/"><img src="<?php echo e($storageUrl.'/img/logo1.png'); ?>" alt=""></a>
        </div>
        <div class="nav">
            <ul>
                <li><a href="#contacto"><i class="flaticon-mesa-de-ayuda"> </i>Contacto</a></li>
                <li><a href="#ubicacion"><i class="flaticon-ubicacion"> </i>Ubicación</a></li>
                <li><a href="#producto"><i class="flaticon-gas"> </i>Productos</a></li>
            </ul>
        </div>
    </div>
</header>

<section class="slider">
    <div class="fondo-img-bg" style="background-image: url(<?php echo e($storageUrl.'/img/fondo1.jpg'); ?>);"></div>
    <div class="owl-slider owl-carousel owl-theme owl-general owl-general--centrar-navegadores">
        
            <?php if($id->img_slider_1): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_1); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>    
            
            <?php if($id->img_slider_2): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_2); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  
            
            <?php if($id->img_slider_3): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_3); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  

            <?php if($id->img_slider_4): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_4); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  

            <?php if($id->img_slider_5): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_5); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  
    
    </div>
</section>

<div class="main" style="background-image:url(<?php echo e($storageUrl.'/img/fondo-productos.jpg'); ?>) ;">
    
    <section class="container-short content">
        <h1><?php echo e($id->name); ?></h1>
        <div class="editor">
            <?php if($id->description): ?>
                <?php echo $id->description; ?>

            <?php else: ?>
                <b>No hay una descripción</b>
            <?php endif; ?>
        </div>
        <div>
            <h3><strong>Métodos de pago</strong></h3>
            <ul class="list">
                <?php if($id->payment_methods): ?>
                    <?php $__currentLoopData = $id->payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><img src="<?php echo e($storageUrl.'/img/'.$pm['img_method']); ?>" alt=""></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>                
            </ul>
        </div>
        <div id="contacto">
            <h3 style="margin: 0;"><strong>Pedidos y atención al cliente</strong></h3>
        </div>
        <div class="telefono">
            <p><strong>Teléfono:</strong></p>
            <ul>
                <?php if($id->phone_numbers): ?>
                    <?php $__currentLoopData = $id->phone_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="tel:<?php echo e($pn['number']); ?>" class="btn btn2 btn-icon"><i class="flaticon-llamada-telefonica-1"> </i><?php echo e($pn['number']); ?></a></li>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            
            </ul>
        </div>

        <div class="telefono">
            <p><strong>Whatsapp:</strong></p>
            <ul>
                <?php if($id->num_what): ?>
                    <?php $__currentLoopData = $id->num_what; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pnw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="https://api.whatsapp.com/send/?phone=51<?php echo e($pnw['numwhat']); ?>&amp;text=Hola%2C+squisiera+por+favor+un+galon+de+gas&amp;app_absent=0" class="btn btn2 btn-icon"><i class="flaticon flaticon-whatsapp"> </i><?php echo e($pnw['numwhat']); ?></a></li>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            
            </ul>
        </div>
    
        <div class="correo">
            <b>Correo:</b>

            <ul>
                <?php if($id->emails): ?>
                    <?php $__currentLoopData = $id->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="" class="btn btn2 btn-icon"><i class="flaticon-email"> </i><?php echo e($e['name']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </ul>   
        </div>        

        <?php if(is_null($id->link_face) && is_null($id->link_insta)): ?>
            <div class="telefono">
            </div>
        <?php else: ?>
            <div class="telefono">
                <p><strong>Síguenos en:</strong></p>
                <ul>
                    <?php if(isset($id->link_face)): ?>
                        <li><a href="<?php echo e($id->link_face); ?>" class="btn btn-circle"><i class="flaticon-facebook"></i></a></li>
                    <?php endif; ?>

                    <?php if(isset($id->link_insta)): ?>
                        <li><a href="<?php echo e($id->link_insta); ?>" class="btn btn-circle"><i class="flaticon-instagram-1"></i></a></li>
                    <?php endif; ?>                        
                </ul>
            </div>          
        <?php endif; ?>
    
        <div class="ubicacion" id="ubicacion">
            <b>Ubicación:</b>
            <p><i class="flaticon flaticon-marcador-de-posicion"> </i><?php echo e($id->direction); ?></p>
            <div class="mapa">
                <?php if($id->iframe): ?>
                        <?php echo $id->iframe; ?>

                    <?php endif; ?>
            </div>
        </div>
    
    </section>

    <section class="section-productos" id="producto">
        <div class="text-center">
            <div class="container">
                
                <img src="<?php echo e($storageUrl.'/img/icon.png'); ?>" alt="">
                <h2><strong>Nuestros Productos para tu Hogar</strong></h2>
                <br><br>
                <div id="slider-historia">                        
                    <?php
                        function object_sorter($clave,$orden=null) {
                            return function ($a, $b) use ($clave,$orden) {
                                $result=  ($orden=="DESC") ? strnatcmp($b->$clave, $a->$clave) :  strnatcmp($a->$clave, $b->$clave);
                                return $result;
                            };
                        }
                        $listproductos = json_decode($id->productos);
                        usort($listproductos, object_sorter('index'));
                    ?>
                    <?php if($listproductos): ?>
                        <div class="content-limagas">
                            <?php $__currentLoopData = $listproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($e->tipogas == "limagas"): ?>
                                        <div class="card card-balon">
                                            <img class="lazyload" src="<?php echo e($storageUrl . '/img/productos/' . $e->image); ?>" alt="<?php echo e($e->name); ?>" />
                                            <div class="content-balon">
                                                <h4><?php echo e($e->name); ?></h4>
                                                <span><?php echo e($e->precio); ?> kg</span>
                                            </div>                                            
                                        </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                        </div>
                    <?php endif; ?>
    
                    <?php if($listproductos): ?>
                        <div class="content-otrogas">
                            
                                <?php $__currentLoopData = $listproductos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($e->tipogas == "otrotipogas"): ?>
                                        <div class="card card-balon">
                                            <img class="lazyload" src="<?php echo e($storageUrl . '/img/productos/' . $e->image); ?>" alt="<?php echo e($e->name); ?>" />
                                            <div class="content-balon">
                                                <h4><?php echo e($e->name); ?></h4>
                                                <span><?php echo e($e->precio); ?> kg</span>
                                            </div>                                            
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>  
                    <?php endif; ?>
    
                </div>

            </div>  
        </div>
    </section>

    
</div>

<div class="pie"></div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('.owl-balones-limagas.owl-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1049: {
                    items: 5
                }
            }
        });

        $('.owl-balones-otrotipo.owl-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1049: {
                    items: 5
                }
            }
        });


        $('.owl-slider.owl-carousel').owlCarousel({
            loop: false,
            margin: 30,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1.2,
                    margin: 20
                },
                600: {
                    items: 1.3
                },
                1049: {
                    items: 1.9
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/web/pages/distribuidor.blade.php ENDPATH**/ ?>