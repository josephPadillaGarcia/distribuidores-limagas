<?php $__env->startSection('content'); ?>
<?php
    $storageUrl = config('services.storage_url');
?>

<header class="header-distribuidor img-bg" style="background-image: url(<?php echo e($storageUrl.'/img/fondo1.jpg'); ?>);">
    <div class="container-short grid-single color_white">
        <div class="logo">
            <img src="<?php echo e($storageUrl.'/img/logo1.png'); ?>" alt="">
        </div>
        <div class="nav">
            <ul>
                <li><a href=""><i class="flaticon-mesa-de-ayuda"> </i>Contacto</a></li>
                <li><a href=""><i class="flaticon-ubicacion"> </i>Ubicación</a></li>
                <li><a href=""><i class="flaticon-gas"> </i>Productos</a></li>
            </ul>
        </div>
    </div>
</header>

<section class="slider">
    <div class="fondo-img-bg" style="background-image: url(<?php echo e($storageUrl.'/img/fondo1.jpg'); ?>);"></div>
    <div class="owl-slider owl-carousel owl-theme owl-general owl-general--centrar-navegadores">
        
            <?php if($id->img_slider_1): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_1); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>    
            
            <?php if($id->img_slider_2): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_2); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  
            
            <?php if($id->img_slider_3): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_3); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  

            <?php if($id->img_slider_4): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_4); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  

            <?php if($id->img_slider_5): ?>
                <div class="item">
                    <img class="card__image" src="<?php echo e($storageUrl . '/img/sliders/' . $id->img_slider_5); ?>" alt="<?php echo e($id->name); ?>" />
                </div>
            <?php endif; ?>  
    
    </div>
</section>

<div class="main" style="background-image:url(<?php echo e($storageUrl.'/img/fondo-productos.jpg'); ?>) ;">
    
    <section class="container-short content">
        <h1><?php echo e($id->name); ?></h1>
        <div class="editor">
            <?php if($id->description): ?>
                <?php echo $id->description; ?>

            <?php else: ?>
                <b>No hay una descripción</b>
            <?php endif; ?>
        </div>
        <div>
            <h3><strong>Métodos de pago</strong></h3>
            <ul class="list">
                <?php if($id->payment_methods): ?>
                    <?php $__currentLoopData = $id->payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><img src="<?php echo e($storageUrl.'/img/'.$pm['img_method']); ?>" alt=""></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>                
            </ul>
        </div>
        <div>
            <h3 style="margin: 0;"><strong>Pedidos y atención al cliente</strong></h3>
        </div>
        <div class="telefono">
            <p><strong>Teléfono:</strong></p>
            <ul>
                <?php if($id->phone_numbers): ?>
                    <?php $__currentLoopData = $id->phone_numbers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="" class="btn btn2 btn-icon"><i class="flaticon flaticon-telefono"> </i><?php echo e($pn['number']); ?></a></li>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            
            </ul>
        </div>

        <div class="telefono">
            <p><strong>Whatsapp:</strong></p>
            <ul>
                <?php if($id->num_what): ?>
                    <?php $__currentLoopData = $id->num_what; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pnw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="" class="btn btn2 btn-icon"><i class="flaticon flaticon-whatsapp"> </i><?php echo e($pnw['numwhat']); ?></a></li>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            
            </ul>
        </div>
    
        <div class="correo">
            <b>Correo:</b>

            <ul>
                <?php if($id->emails): ?>
                    <?php $__currentLoopData = $id->emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="" class="btn btn2 btn-icon"><i class="flaticon-email"> </i><?php echo e($e['name']); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </ul>   
        </div>
    
        <div class="ubicacion">
            <b>Ubicación:</b>
            <p><i class="flaticon flaticon-send"> </i><?php echo e($id->direction); ?></p>
            <div class="mapa">
                <?php if($id->iframe): ?>
                        <?php echo $id->iframe; ?>

                    <?php endif; ?>
            </div>
        </div>
    
    </section>


    <section class="section-productos">
        <div class="text-center">
            <div class="container-short">
                
                <img src="<?php echo e($storageUrl.'/img/icon.png'); ?>" alt="">
                <h2><strong>Nuestros Productos para tu Hogar</strong></h2>
                <br><br>
            </div>  
            <div id="slider-historia">
                <?php if($id->products): ?>
                    <div class="owl-balones-limagas owl-carousel owl-theme owl-general owl-general--centrar-navegadores">

                        <?php $__currentLoopData = $id->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($e['tipogas'] == "limagas"): ?>
                                <div class="item">
                                    <div class="card card-balon">
                                        <img class="lazyload" src="<?php echo e($storageUrl . '/img/productos/' . $e['image']); ?>" alt="<?php echo e($e['name']); ?>" />
                                        <div class="content-balon">
                                            <h4><?php echo e($e['name']); ?></h4>
                                            <span><?php echo e($e['precio']); ?> kg</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>  
                <?php endif; ?>

                <?php if($id->products): ?>
                    <div class="owl-balones-otrotipo owl-carousel owl-theme owl-general owl-general--centrar-navegadores">
                        
                            <?php $__currentLoopData = $id->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($e['tipogas'] == "otrotipogas"): ?>
                                    <div class="item">
                                        <div class="card card-balon">
                                            <img class="lazyload" src="<?php echo e($storageUrl . '/img/productos/' . $e['image']); ?>" alt="<?php echo e($e['name']); ?>" />
                                            <div class="content-balon">
                                                <h4><?php echo e($e['name']); ?></h4>
                                                <span><?php echo e($e['precio']); ?> kg</span>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>  
                <?php endif; ?>

            </div>
        </div>
    </section>
</div>

<div class="pie"></div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $('.owl-balones-limagas.owl-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1049: {
                    items: 5
                }
            }
        });

        $('.owl-balones-otrotipo.owl-carousel').owlCarousel({
            loop: false,
            margin: 10,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1049: {
                    items: 5
                }
            }
        });


        $('.owl-slider.owl-carousel').owlCarousel({
            loop: false,
            margin: 30,
            nav: true,
            center: true,
            dots: true,
            autoplay: true,
            autoplayTimeout: 4000,
            autoplayHoverPause: true,
            navText: ["<span class='flaticon-atras'></span>","<span class='flaticon-proximo'></span>"],
            responsive: {
                0: {
                    items: 1.2,
                    margin: 20
                },
                600: {
                    items: 1.3
                },
                1049: {
                    items: 1.9
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/web/pages/distribuidor.blade.php ENDPATH**/ ?>