<?php $__env->startSection('head'); ?>
<style>
    .mx-panel-time .mx-time-list:nth-child(3){
        display: none;
    }
    .mx-panel-time .mx-time-list:nth-child(1), .mx-panel-time .mx-time-list:nth-child(2) {
        width: 50% !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <productos
    message-order="<?php echo app('translator')->get('custom.message.order'); ?>"
    route="<?php echo e(route('cms.productos.index')); ?>" 
    route-order="<?php echo e(route('cms.productos.order')); ?>"
    images-url="<?php echo e(config('services.images_url')); ?>"
    route-get-all="<?php echo e(route('cms.productos.get-all')); ?>"
    ></productos>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto-frelos\distribuidores-limagas\resources\views/admin/pages/productos/index.blade.php ENDPATH**/ ?>