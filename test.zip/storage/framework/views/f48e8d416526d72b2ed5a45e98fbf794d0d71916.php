<?php
/*$webUrl = config('services.web_url');
$storageUrl = config('services.storage_url');
$locale = App::getLocale();
/*if(Route::currentRouteName() == 'service') {
    $page["title_" . $locale] = $service["seo_title_" . $locale];
    $page["seo_description_" . $locale] = $service["seo_description_" . $locale];
    $page["seo_keywords_" . $locale] = $service["seo_keywords_" . $locale];
    $page["seo_image"] = $service["seo_image"];
}
if(Route::currentRouteName() == 'new') {
    $page["title_" . $locale] = $data["new"]["title_" . $locale];
    $page["seo_description_" . $locale] = $data["new"]["excerpt_" . $locale];
    $page["seo_keywords_" . $locale] = $data["new"]["seo_keywords_" . $locale];
    $page["seo_image"] = $data["new"]["thumbnail"];
}*/
?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">  
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Distribuidores</title>
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo e(asset('storage/img/icon.png')); ?>">
    <link rel="manifest" href="<?php echo e(asset('storage/img/icon.png')); ?>">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('storage/img/icon.png')); ?>">
    <meta name="theme-color" content="#ffffff">
    <link href="<?php echo e(asset('css/web/remixicon.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/web/fonts.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/web/new-style.css')); ?>" rel="stylesheet">
    <!--link href="<?php echo e(asset('css/web/bootstrap.min.css')); ?>" rel="stylesheet"-->
    <link href="<?php echo e(asset('css/web/flaticon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/web/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/web/jq.fancybox.min.css')); ?>" rel="stylesheet">
    <!--link href="<?php echo e(asset('css/web.css')); ?>" rel="stylesheet"-->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>

<body>
    <div id="app">
        <?php echo $__env->make('web.layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('web.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
    </div>
    <script src="<?php echo e(asset('js/web/manifest.js')); ?>"></script>
    <script src="<?php echo e(asset('js/web/vendor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/web/web.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    
</body>

</html><?php /**PATH C:\wamp64\www\proyectos-free\distribuidores-limagas\resources\views/web/layouts/app.blade.php ENDPATH**/ ?>