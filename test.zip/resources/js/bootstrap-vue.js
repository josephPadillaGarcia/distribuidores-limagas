import { ModalPlugin, FormCheckboxPlugin, DropdownPlugin, CollapsePlugin, PopoverPlugin, TooltipPlugin,FormRadioPlugin, TabsPlugin   } from 'bootstrap-vue'

Vue.use(CollapsePlugin);
Vue.use(DropdownPlugin);
Vue.use(ModalPlugin);
Vue.use(FormCheckboxPlugin);
Vue.use(PopoverPlugin);
Vue.use(TooltipPlugin);
Vue.use(FormRadioPlugin);
Vue.use(TabsPlugin);
