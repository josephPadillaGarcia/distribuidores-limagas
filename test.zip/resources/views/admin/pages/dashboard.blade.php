@extends('admin.layouts.dashboard')
@section('content')
   <dashboard images-url="{{ config('services.images_url') }}"></dashboard>
@endsection