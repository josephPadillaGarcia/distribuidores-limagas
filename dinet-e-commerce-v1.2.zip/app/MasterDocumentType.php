<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterDocumentType extends Model
{
  protected $table = 'master_documents_type';
}
