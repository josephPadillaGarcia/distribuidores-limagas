<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AppTracking extends Model
{
    protected $table = 'info_app_tracking';
    protected $guarded = [];
}
