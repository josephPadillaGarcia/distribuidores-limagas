<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterSocialNetwork extends Model
{
    protected $table = 'master_social_networks';
    protected $guarded = [];
}
