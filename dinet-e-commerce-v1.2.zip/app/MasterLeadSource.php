<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MasterLeadSource extends Model
{
    protected $table = 'master_leads_source';
    protected $guarded = [];
}
