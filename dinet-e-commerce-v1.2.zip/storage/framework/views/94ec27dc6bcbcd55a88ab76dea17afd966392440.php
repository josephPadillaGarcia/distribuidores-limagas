<?php
$information = $footer["information"];
$social_networks = $footer["social_networks"];
$locale = $footer["locale"];
$routeLocale = $footer["routeLocale"];
?>
<footer class="grid align-center lazyload" data-bg="/storage/web/img/footer.png">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-12">
                <div class="logo_blanco">
                    <img class="lazyload" src="/storage/web/img/dinet_blanco.png" alt="" />
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-12">
                <div class="info_footer">
                    <?php if(isset($information['direction'])): ?>
                    <div>
                        <?php echo $information['direction']; ?>

                    </div>
                    <?php endif; ?>
                    <p>
                        <b>Chatbot Whatssapp:</b>
                        <?php if($information['whatsapp_number']): ?>
                        <a class="chatbot-wsp">+51
                            <?php echo e($information['whatsapp_number']); ?>

                        </a>
                        <?php endif; ?>
                    </p>
                    <div class="redes">
                        <?php if(count($social_networks)): ?>
                        <ul class="grid align-center">
                            <?php $__currentLoopData = $social_networks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e($sn['url']); ?>" target="_blank" rel="noopener">
                                    <?php if(isset($sn['master_social_networks']['icon'])): ?>
                                    <i class="<?php echo e('flaticon-' . $sn['master_social_networks']['icon']); ?>"></i>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                <div class="menu_footer">
                    <ul>
                        <li>
                            <a href="<?php echo Helper::getCustomRoute('web.aboutUs', $routeLocale); ?>">
                                <img class="lazyload" src="/storage/web/img/icon_list.png" alt="Sobre Dinet" />
                                <?php echo e(__("Sobre Dinet")); ?>

                            </a>
                        </li>
                        <li>
                            <a href="<?php echo Helper::getCustomRoute('web.services', $routeLocale); ?>">
                                <img class="lazyload" src="/storage/web/img/icon_list.png" alt="Servicios" />
                                <?php echo e(__("Servicios")); ?>

                            </a>
                        </li>
                        <li>
                            <a href="<?php echo Helper::getCustomRoute('web.quotations', $routeLocale); ?>">
                                <img class="lazyload" src="/storage/web/img/icon_list.png" alt="Cotizaciones" />
                                <?php echo e(__("Cotizaciones")); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                <div class="opciones_footer">
                    <ul>
                        <li>
                            <?php if($information['book_link']): ?>
                            <a href="<?php echo e($information['book_link']); ?>">
                                <img class="lazyload" src="/storage/web/img/icon_libro.png" alt="Libro de reclamaciones" />
                                <?php echo e(__("Libro de reclamaciones")); ?>

                            </a>
                            <?php endif; ?>
                        </li>
                        <li>
                            <?php if($information['api_link']): ?>
                            <a href="<?php echo e($information['api_link']); ?>">
                                <span>
                                    <i class="flaticon-settings"></i>
                                </span>
                                <?php if($information['name_api']): ?>
                                <?php echo e($information['name_api']); ?>

                                <?php endif; ?>
                            </a>
                            <?php endif; ?>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="pie">
            <div class="row justify-content-between">
                <div class="col-lg-3 col-md-5 col-sm-12">
                    <div class="copyright">
                        <?php echo e(date("Y")); ?> Dinet © All rights reserved.
                    </div>
                </div>
                <div class="col-lg-3 col-md-5 col-sm-12">
                </div>
            </div>
        </div>
    </div>

    <?php if($information['whatsapp_number']): ?>
    <div class="chat-bot">
        <ul>
            <li class="bot">
                <a class="chatbot-wsp" target="_blank">
                    <img data-src="/storage/web/img/bot.png" class="lazyload" alt="" />
                </a>
            </li>
        </ul>
    </div>
    <?php endif; ?>
</footer>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $("ul.navbar-nav li.dropdown").hover(
                function() {
                    $(this)
                        .find(".dropdown-menu")
                        .stop(true, true)
                        .delay(200)
                        .fadeIn(500);
                },
                function() {
                    $(this)
                        .find(".dropdown-menu")
                        .stop(true, true)
                        .delay(200)
                        .fadeOut(500);
                }
            );

        $(".chatbot-wsp").click(function(e) {
            e.preventDefault();

            let number = <?php echo($information['whatsapp_number']) ?>

            let link = `https://wa.me/+51${number}?text=${encodeURIComponent(
                "Hola quisiera información del servicio"
            )}`;
            
            window.open(link, "_blank");
        })
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Programming\PHP\PG\dinet-e-commerce-cms\resources\views/web/layouts/footer.blade.php ENDPATH**/ ?>