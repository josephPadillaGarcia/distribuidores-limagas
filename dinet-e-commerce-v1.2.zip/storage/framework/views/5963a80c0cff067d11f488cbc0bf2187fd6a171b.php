<?php
$services = $menu["services"];
$information = $menu["information"];
$locale = $menu["locale"];
$routeLocale = $menu["routeLocale"];
?>
<header class="fixed-top" id="content_header">
    <nav class="navbar navbar-expand-lg position-relative" aria-label="Tenth navbar example">
        <div class="container-fluid" id="header_container">
            <div class="logo_dinet" id="header_logo_wrapper">
                <a href="<?php echo Helper::getCustomRoute('web.index', $routeLocale); ?>">
                    <img id="header_logo" class="" src="/storage/web/img/logo_dinet.png" alt="" />
                </a>
            </div>

            <div class="codigo_mobil">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <form-header locale="<?php echo e($locale); ?>" :desktop="false" link="<?php echo e($information['api_url_tracking'] ? $information['api_url_tracking'] : ''); ?>" />
                    </li>
                </ul>
            </div>

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarMain"
                aria-controls="navbarMain"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <i class="flaticon flaticon-boton-de-menu-de-tres-lineas-horizontales"></i>
            </button>

            <div class="collapse navbar-collapse justify-content-end" id="navbarMain">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo Helper::getCustomRoute('web.aboutUs', $routeLocale); ?>">
                            <?php echo e(__("Sobre Dinet")); ?>

                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <div class="list-servicios-mobil">
                            <a class="nav-link dropdown-toggle" href="<?php echo Helper::getCustomRoute('web.services', $routeLocale); ?>" id="navbarDropdown">
                                <?php echo e(__("Servicios")); ?>

                            </a>
                            <span class="icon-drop"><i class="flaticon-descargar"></i></span>
                        </div>
                        <div id="menu-mobil" class="dropdown-menu menu-hover dis-none">
                            <?php if(count($services)): ?>
                            <ul class="content-dropdown" aria-labelledby="navbarDropdown">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="position-relative list-ser">
                                    <a class="dropdown-item" href="<?php echo Helper::getCustomRoute('web.service', $routeLocale, ['slug' => $service['slug_' . $locale] ? $service['slug_' . $locale] : $service['slug_es']]); ?>">
                                        <?php if($service["icon_colour"]): ?>
                                        <img
                                            height="34"
                                            src="<?php echo e($storageUrl . '/img/services/' . $service['icon_colour']); ?>"
                                            class="lazyload"
                                            alt="<?php echo e($service['title_' . $locale]); ?>"
                                        />
                                        <?php endif; ?>
                                        <?php echo e($service["title_" . $locale]); ?>

                                    </a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo Helper::getCustomRoute('web.quotations', $routeLocale); ?>">
                            <?php echo e(__("Cotizaciones")); ?>

                        </a>
                    </li>
                    <li class="nav-item code-send hiden" id="header_code_send">
                        <form-header locale="<?php echo e($locale); ?>" :desktop="true" link="<?php echo e($information['api_url_tracking'] ? $information['api_url_tracking'] : ''); ?>" />
                    </li>
                    <?php if(isset($information['customers_link'])): ?>
                    <li class="nav-item boton">
                        <a class="nav-link text-white text-center" href="<?php echo e($information['customers_link']); ?>" target="_blank">
                            <?php echo e(__("Acceso Clientes")); ?>

                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function () {
        $("ul.navbar-nav li.dropdown").hover(
                function() {
                    $(this)
                        .find(".dropdown-menu")
                        .stop(true, true)
                        .delay(200)
                        .fadeIn(500);
                },
                function() {
                    $(this)
                        .find(".dropdown-menu")
                        .stop(true, true)
                        .delay(200)
                        .fadeOut(500);
                }
            );
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH E:\Programming\PHP\PG\dinet-e-commerce-cms\resources\views/web/layouts/menu.blade.php ENDPATH**/ ?>