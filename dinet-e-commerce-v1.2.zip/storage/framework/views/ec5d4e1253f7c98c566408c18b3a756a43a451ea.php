<?php $__env->startSection('content'); ?>
<?php
    $webUrl = config('services.web_url');
    $storageUrl = config('services.storage_url');
    $content = $data["content"];
    $services = $data["services"];
    $appTracking = $data["appTracking"];
    $tutos = $data["tutos"];
    $customers = $data["customers"];
    $footer = $data["footer"];
    $locale = $data["locale"];
    $routeLocale = $data["routeLocale"];
    $page = $data["page"];
?>
  <main>
        <section class="position-relative marginb_section section_bannerHome section_bannerHome_02" id="seccion_banner_global">
            <?php
            $index_banner = array_search("Banner", array_column($content, 'name'));
            $banner = $content[$index_banner];

            $image_banner = "";
            if(in_array("image", $banner["content_formatted"])) {
              $index = array_search("image", array_column($banner["content"], 'field'));
              $image_banner = $storageUrl . '/img/content/' . $banner["content"][$index]["value"];
            }

            $video_banner = "";
            if(in_array("video", $banner["content_formatted"])) {
              $index = array_search("video", array_column($banner["content"], 'field'));
              $video_banner = $storageUrl . '/videos/pages/' . $banner["content"][$index]["value"];
            }
            ?>
            <template>
                <video
                    ref="ref_video"
                    class="lazyload"
                    data-poster="<?php echo e($image_banner); ?>"
                    loop
                    autoplay
                    muted
                    playsinline
                    preload="none"
                >
                  <?php if($video_banner): ?>
                    <source
                        type="video/mp4"
                        src="<?php echo e($video_banner); ?>"
                    />
                  <?php endif; ?>
                </video>
            </template>
            <?php
            $description_banner = "";
            if(in_array('description', $banner["content_formatted"])) {
              $index = array_search("description", array_column($banner["content"], 'field'));
              $description_banner = $banner["content"][$index]["value_" . $locale];
            }
            ?>
            <div class="container">
                <div class="row">
                    <div class="col-md-7 px-0">
                        <div class="content_banner">
                          <?php if($description_banner): ?>
                            <div>
                              <?php echo $description_banner; ?>

                            </div>
                            <form-index locale="<?php echo e($locale); ?>" storage-url="<?php echo e($storageUrl); ?>" link="<?php echo e($footer['information']['api_url_tracking'] ? $footer['information']['api_url_tracking'] : ''); ?>"></form-index>
                          <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php if(count($services)): ?>
        <section
            id="seccion_slider_soluciones"
            class="bottom_section"
        >
            <div class="container">
                <div class="row">
                  <?php
                    $index_servicios = array_search("Servicios", array_column($content, 'name'));
                    $servicios = $content[$index_servicios];

                    $title_servicios = "";
                    if(in_array('title',$servicios["content_formatted"])) {
                      $index = array_search("title", array_column($servicios["content"], 'field'));
                      $title_servicios = $servicios["content"][$index]["value_" . $locale];
                    }
                  ?>
                    <div class="titulo_global">
                        <b><?php echo e(__("Servicios")); ?></b>
                        <?php if($title_servicios): ?>
                        <h2><?php echo e($title_servicios); ?></h2>
                        <?php endif; ?>
                    </div>

                    <?php if(count($services)): ?>
                    <div class="col-lg-12">
                        <div class="owl-carousel owl-theme carousel_saluciones position-relative">
                          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <!-- ItemService -->
                                <div class="item">
                                    <a href="<?php echo Helper::getCustomRoute('web.service', $routeLocale, ['slug' => $service['slug_' . $locale] ? $service['slug_' . $locale] : $service['slug_es']]); ?>">
                                      <?php if($service["image"]): ?>
                                        <img class="lazyload" src="<?php echo e($storageUrl . '/img/services/' . $service['image']); ?>" alt="<?php echo e('Imagen ' . $service['title_' . $locale ]); ?>" />
                                      <?php endif; ?>
                                  </a>
                                    <div class="content_solucion position-relative">
                                        <span class="position-absolute icons-solucion">
                                          <?php if($service["icon_white"]): ?>
                                            <img class="lazyload" src="<?php echo e($storageUrl . '/img/services/' . $service['icon_white']); ?>" alt="<?php echo e('Icono ' . $service['title_' . $locale ]); ?>" />
                                          <?php endif; ?>
                                        </span>
                                        <b class="text-center"><?php echo e($service["title_" . $locale]); ?></b>
                                        <p class="text-center"><?php echo e($service["excerpt_" . $locale]); ?></p>
                                        <a href="<?php echo Helper::getCustomRoute('web.service', $routeLocale, ['slug' => $service['slug_' . $locale] ? $service['slug_' . $locale] : $service['slug_es']]); ?>" class="btn_global btn_border text-center btn_color_text">
                                            <?php echo e(__("Conoce más")); ?>

                                        </a>
                                    </div>
                                </div>
                                <!-- EndItemService -->
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <?php if($appTracking): ?>
        <section id="section_rastreo" class="bottom_section lazyload position-relative rastreo">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 img_cinta">
                      <?php if($appTracking['image']): ?>
                        <img src="<?php echo e($storageUrl . '/img/app-tracking/' . $appTracking['image']); ?>" class="lazyload" alt="Dinet App"
                        />
                      <?php endif; ?>
                    </div>
                    <div class="col-lg-6 info_rastreo">
                        <div class="content_text_rastreo">
                          <?php if($appTracking['title_' . $locale]): ?>
                            <div>
                                <?php echo $appTracking['title_' . $locale]; ?>

                            </div>
                          <?php endif; ?>
                          <?php if($appTracking['description_' . $locale]): ?>
                            <div>
                                <?php echo $appTracking['description_' . $locale]; ?>

                            </div>
                          <?php endif; ?>
                        </div>
                        <div class="img_apps">
                          <?php if($appTracking['link_ios']): ?>
                            <a href="<?php echo e($appTracking['link_ios']); ?>" target="_blank">
                                <img src="/storage/web/img/app_apple.png" class="lazyload" alt="" />
                            </a>
                          <?php endif; ?>
                          <?php if($appTracking['link_android']): ?>
                            <a href="<?php echo e($appTracking['link_android']); ?>" target="_blank">
                                <img src="/storage/web/img/app_google.png" class="lazyload" alt="" />
                            </a>
                          <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <?php if(count($tutos)): ?>
        <section id="section_tutoriales" class="bottom_section">
            <div class="container">
                <div class="row">
                  <?php
                    $index_tutoriales = array_search("Tutoriales", array_column($content, 'name'));
                    $tutoriales = $content[$index_tutoriales];

                    $subtitle_tutoriales = "";
                    if(in_array('subtitle', $tutoriales["content_formatted"])) {
                      $index = array_search("subtitle", array_column($tutoriales["content"], 'field'));
                      $subtitle_tutoriales = $tutoriales["content"][$index]["value_" . $locale];
                    }

                    $title_tutoriales = "";
                    if(in_array('title', $tutoriales["content_formatted"])) {
                      $index = array_search("title", array_column($tutoriales["content"], 'field'));
                      $title_tutoriales = $tutoriales["content"][$index]["value_" . $locale];
                    }
                  ?>
                    <div class="titulo_global">
                      <?php if($subtitle_tutoriales): ?>
                        <b>
                            <?php echo e($subtitle_tutoriales); ?>

                        </b>
                      <?php endif; ?>
                      <?php if($title_tutoriales): ?>
                        <h2>
                            <?php echo e($title_tutoriales); ?>

                        </h2>
                      <?php endif; ?>
                    </div>
                  <?php $__currentLoopData = $tutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tuto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6">
                        <div class="content_tutorial">
                            <img
                                class="img_tutorial lazyload"
                                src="<?php echo e($storageUrl . '/img/tutorials/' . $tuto['image']); ?>"
                                alt=""
                            />
                            <div class="caja_pregunta">
                                <p><?php echo e($tuto["title_" . $locale]); ?></p>
                                <!-- <a class="position-relative fancybox" data-fancybox="Tutoriales" :href="el.link">$t("Ver video") -->
                                <a class="position-relative fancybox" data-fancybox="Tutoriales" href="<?php echo e($tuto['link']); ?>">
                                    <?php echo e(__("Ver video")); ?>

                                    <span class="position-absolute">
                                        <img src="/storage/web/img/flecha_iz.png" class="lazyload" alt=""/>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  <?php
                    $url_tutoriales = "";
                    if(in_array('url_tutos', $tutoriales["content_formatted"])) {
                      $index = array_search("url_tutos", array_column($tutoriales["content"], 'field'));
                      $url_tutoriales = $tutoriales["content"][$index]["value_es"];
                    }
                  ?>
                  <?php if($url_tutoriales): ?>
                    <div class="content_boton">
                        <a target="_blank" href="<?php echo e($url_tutoriales); ?>" class="b_boton text-white text-center btn_global">
                            <?php echo e(__("Ver más tutoriales")); ?>

                        </a>
                    </div>
                  <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <?php
          $index_experience = array_search("Sumando experiencia en cada servicio", array_column($content, 'name'));
          $experience = $content[$index_experience];

          $title_experience = "";
          if(in_array('title', $experience["content_formatted"])) {
            $index = array_search("title", array_column($experience["content"], 'field'));
            $title_experience = $experience["content"][$index]["value_" . $locale];
          }

          $icon_a_experience = "";
          if(in_array('icon_1', $experience["content_formatted"])) {
            $index = array_search("icon_1", array_column($experience["content"], 'field'));
            $icon_a_experience = $storageUrl . '/img/content/' . $experience["content"][$index]["value"];
          }

          $count_a_experience = "";
          if(in_array('count_1', $experience["content_formatted"])) {
            $index = array_search("count_1", array_column($experience["content"], 'field'));
            $count_a_experience = $experience["content"][$index]["value_" . $locale];
          }

          $feature_a_experience = "";
          if(in_array('feature_1', $experience["content_formatted"])) {
            $index = array_search("feature_1", array_column($experience["content"], 'field'));
            $feature_a_experience = $experience["content"][$index]["value_" . $locale];
          }

          $icon_b_experience = "";
          if(in_array('icon_2', $experience["content_formatted"])) {
            $index = array_search("icon_2", array_column($experience["content"], 'field'));
            $icon_b_experience = $storageUrl . '/img/content/' . $experience["content"][$index]["value"];
          }

          $count_b_experience = "";
          if(in_array('count_2', $experience["content_formatted"])) {
            $index = array_search("count_2", array_column($experience["content"], 'field'));
            $count_b_experience = $experience["content"][$index]["value_" . $locale];
          }

          $feature_b_experience = "";
          if(in_array('feature_2', $experience["content_formatted"])) {
            $index = array_search("feature_2", array_column($experience["content"], 'field'));
            $feature_b_experience = $experience["content"][$index]["value_" . $locale];
          }

          $icon_c_experience = "";
          if(in_array('icon_3', $experience["content_formatted"])) {
            $index = array_search("icon_3", array_column($experience["content"], 'field'));
            $icon_c_experience = $storageUrl . '/img/content/' . $experience["content"][$index]["value"];
          }

          $count_c_experience = "";
          if(in_array('count_3', $experience["content_formatted"])) {
            $index = array_search("count_3", array_column($experience["content"], 'field'));
            $count_c_experience = $experience["content"][$index]["value_" . $locale];
          }

          $feature_c_experience = "";
          if(in_array('feature_3', $experience["content_formatted"])) {
            $index = array_search("feature_3", array_column($experience["content"], 'field'));
            $feature_c_experience = $experience["content"][$index]["value_" . $locale];
          }
        ?>
        <section id="section_datos" class="lazyload" data-bg="/storage/web/img/fondo_mapa.png">
            <div class="container">
                <div class="row justify-content-between">
                    <div class="col-lg-6 col-md-12 grid align-center">
                        <div class="content_text_rastreo">
                          <?php if($title_experience): ?>
                            <div>
                              <?php echo $title_experience; ?>

                            </div>
                          <?php endif; ?>

                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 datos">
                                  <?php if($icon_a_experience): ?>
                                    <img class="lazyload" src="<?php echo e($icon_a_experience); ?>" alt="" />
                                  <?php endif; ?>

                                    <b style="<?php echo e($count_a_experience ? 'display:block;' : 'display:none;'); ?>" class="counter">
                                        <?php echo e($count_a_experience); ?>

                                    </b>

                                  <?php if($feature_a_experience): ?>
                                    <p>
                                        <?php echo e($feature_a_experience); ?>

                                    </p>
                                  <?php endif; ?>
                                </div>
                                
                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 datos">
                                  <?php if($icon_b_experience): ?>
                                    <img class="lazyload" src="<?php echo e($icon_b_experience); ?>" alt="" />
                                  <?php endif; ?>

                                    <b style="<?php echo e($count_b_experience ? 'display:block;' : 'display:none;'); ?>" class="counter">
                                        <?php echo e($count_b_experience); ?>

                                    </b>

                                  <?php if($feature_b_experience): ?>
                                    <p>
                                        <?php echo e($feature_b_experience); ?>

                                    </p>
                                  <?php endif; ?>
                                </div>

                                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 datos">
                                  <?php if($icon_c_experience): ?>
                                    <img class="lazyload" src="<?php echo e($icon_c_experience); ?>" alt="" />
                                  <?php endif; ?>

                                    <b style="<?php echo e($count_c_experience ? 'display:block;' : 'display:none;'); ?>" class="counter">
                                        <?php echo e($count_c_experience); ?>

                                    </b>

                                  <?php if($feature_c_experience): ?>
                                    <p>
                                        <?php echo e($feature_c_experience); ?>

                                    </p>
                                  <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                  <?php
                  $image_experience = "";
                  if(in_array('image', $experience["content_formatted"])) {
                    $index = array_search("image", array_column($experience["content"], 'field'));
                    $image_experience = $storageUrl . '/img/content/' . $experience["content"][$index]["value"];
                  }
                  ?>
                    <div class="col-lg-5 col-md-5 grid align-end">
                      <?php if($image_experience): ?>
                        <div class="img_dato">
                            <img class="lazyload" src="<?php echo e($image_experience); ?>" alt="" />
                        </div>
                      <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <?php if(count($customers)): ?>
        <section id="section_clientes" class="bottom_section">
            <div class="container">
              <?php
              $index_clientes = array_search("Nuestros Clientes", array_column($content, 'name'));
              $clientes = $content[$index_clientes];

              $title_clientes = "";
              if(in_array('title', $clientes["content_formatted"])) {
                $index = array_search("title", array_column($clientes["content"], 'field'));
                $title_clientes = $clientes["content"][$index]["value_" . $locale];
              }
              ?>
                <div class="row">
                    <div class="titulo_global">
                      <?php if($title_clientes): ?>
                        <h2>
                            <?php echo e($title_clientes); ?>

                        </h2>
                      <?php endif; ?>
                    </div>
                    <div class="col-lg-12">
                        <div class="owl-carousel owl-theme carousel_clientes position-relative">
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item">
                                    <img class="lazyload" src="<?php echo e($storageUrl . '/img/customers/' . $customer['image']); ?>" alt="<?php echo e($customer['name']); ?>" />
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php endif; ?>

        <?php 
        $index_stores = array_search("Contamos con cuatro DARK STORE en lima para atender el e-commerce", array_column($content, 'name'));
        $stores = $content[$index_stores];

        $image_stores = "";
        if(in_array('image', $stores["content_formatted"])) {
          $index = array_search("image", array_column($stores["content"], 'field'));
          $image_stores = $storageUrl . '/img/content/' . $stores["content"][$index]["value"];
        }
        
        $text_stores = "";
        if(in_array('text', $stores["content_formatted"])) {
          $index = array_search("text", array_column($stores["content"], 'field'));
          $text_stores = $stores["content"][$index]["value_" . $locale];
        }
        ?>
        <section id="section_darkstore" class="bottom_section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5 grid align-center">
                        <div class="man-dinet">
                          <?php if($image_stores): ?>
                            <img class="lazyload" src="<?php echo e($image_stores); ?>" alt="" />
                          <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-7 grid align-center">
                        <div class="content_store">
                          <?php if($text_stores): ?>
                            <div>
                              <?php echo $text_stores; ?>

                            </div>
                          <?php endif; ?>

                          <?php
                          $footer_information = $footer["information"] ? $footer["information"] : "";

                          $footer_contact_number = "";
                          if($footer_information) {
                            $footer_contact_number = $footer_information["contact_number"] ? $footer_information["contact_number"] : "";
                          }
                          ?>
                            <div class="caja_botones">
                              <?php if($footer_contact_number): ?>
                                <a href="<?php echo e('tel:+51' . $footer_contact_number); ?>" class="btn_global btn_border text-center btn_color_text">
                                  +51 <?php echo e($footer_information["contact_number_format"]); ?>

                                </a>
                              <?php endif; ?>
                                <a
                                    href="<?php echo Helper::getCustomRoute('web.quotations', $routeLocale); ?>"
                                    class="b_boton text-white text-center btn_global"
                                >
                                    <?php echo e(__("Quiero cotizar")); ?>

                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
  $(document).ready(function () {
      $(".fancybox").fancybox();
      $(".counter").counterUp({
        delay: 10,
        time: 5000,
      });
      $(".carousel_clientes").owlCarousel({
        loop: true,
        lazyLoad: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
          0: {
            items: 2,
          },
          600: {
            items: 3,
          },
          1000: {
            items: 6,
          },
        },
      });
      $(".carousel_saluciones").owlCarousel({
        loop: true,
        lazyLoad: true,
        margin: 10,
        nav: true,
        autoplay: true,
        autoplayTimeout: 3000,
        responsive: {
          0: {
            items: 1,
          },
          600: {
            items: 2,
          },
          1000: {
            items: 3,
          },
        },
      });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('web.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Programming\PHP\PG\dinet-e-commerce-cms\resources\views/web/pages/index.blade.php ENDPATH**/ ?>